CSC 172 Lab

Contact 
-----------------------------------------
Uzair Tahamid Siam
email: usiam@u.rochester.edu
URID: 31434546 / NETID: usiam
Partner; Abrar Rahman Protyasha
Lab session - M/W 6:15 - 7:30
-----------------------------------------

Synopsis
----------------------------------------
Lab 2 tests our knowledge on Java Generics and shows us how to work around the need of using overloaded methods. 

Compiling instructions
---------------------------------------
Just run the file in eclipse. All example test cases are included.