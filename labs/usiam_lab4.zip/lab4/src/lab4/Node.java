package lab4;

public class Node<T> {

	T data;
	Node<T> next;

}
