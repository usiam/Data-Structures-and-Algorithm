import java.util.*;

public class lab1 {
	
	public static void main(String[] args) {
		
		System.out.println(isAnagram("QWEsrTy","QWEsrTy"));
		
	}
	
	
	
	//Question 1
	public static boolean isAnagram(String s1, String s2) {
		
		if(s1.length() != s2.length()) {//if length is not same they can never be anagrams
			return false;
		}
		
		char[] s1CharArray = s1.toCharArray(); //turns string into a character array
		Arrays.sort(s1CharArray); //sorts the character array
		
		char[] s2CharArray = s2.toCharArray();
		Arrays.sort(s2CharArray);
		
		if(Arrays.equals(s1CharArray, s2CharArray)) { //if the two character arrays are equal returns true
			return true;
		} else { //else returns false
			return false;
		}
		
	}
	
	
	//Question 2
	public static boolean isRotation(String s1, String s2) {
		
		if(!isAnagram(s1, s2)) {
			return false;
		} else {
			String temp = s1 + s2;
			if(s2.)
		}
		
		
		
		return false;
	}
}
