CSC 172 Lab

Contact 
-----------------------------------------
Uzair Tahamid Siam
email: usiam@u.rochester.edu
URID: 31434546 / NETID: usiam
Partner; Abrar Rahman Protyasha
Lab session - M/W 6:15 - 7:30
-----------------------------------------

Synopsis
----------------------------------------
Lab 1 (Java refresher) uses the idea of string manipulation and use of certain string class methods and/or array operations to find whether a string s1 is an anagram and a rotation of another
string s2. 

Compiling instructions
---------------------------------------
Just run the file. All example test cases are included.