CSC 172 Lab

Contact 
-----------------------------------------
Uzair Tahamid Siam
email: usiam@u.rochester.edu
URID: 31434546 / NETID: usiam
Partner; Abrar Rahman Protyasha
Lab session - M/W 6:15 - 7:30
-----------------------------------------

Synopsis
----------------------------------------
This lab is all about dynamic programming and the importance of keeping track of partial solutions when it comes to making your program run faster (evident from the 'calls' counter that is displayed in the console when the program is run).

Classes
----------------------------------------
Lab6.java contains the main method.
MakeChange.java and MakeChangeDynamicProgramming.java  are where most of the work is done. These calculate the most optimized way to return the required change.
Utility.java contains the loop that is required in MakeChange and MakeChangeDynamicProgramming classes.
