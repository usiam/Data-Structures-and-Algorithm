CSC 172 Lab

Contact 
-----------------------------------------
Uzair Tahamid Siam
email: usiam@u.rochester.edu
URID: 31434546 / NETID: usiam
Partner; Abrar Rahman Protyasha
Lab session - M/W 6:15 - 7:30
-----------------------------------------

Synopsis
----------------------------------------
Lab 3 aims to provide us practice on how to deal with 2D arrays and arralist which will be essential for the 2nd project. 

Compiling instructions
---------------------------------------
Import the source file into eclipse and run the code. There are three classes as the lab asked for each labelled Task1, Task2, and Task3. 
The .java files are inside /src/lab3